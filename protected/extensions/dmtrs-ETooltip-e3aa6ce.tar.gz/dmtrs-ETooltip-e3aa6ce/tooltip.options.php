<?php
return array(
    'cancelDefault',
	'effect',
	'delay',
	'events',
	'layout',
	'offset',
	'opacity',
	'position',
	'predelay',
	'relative',
	'tip',
	'tipClass',
);    
